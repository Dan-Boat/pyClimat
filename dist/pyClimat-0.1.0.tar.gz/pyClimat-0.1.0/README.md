# pyClimat
----------
Climat python package for analysising GCM model output and visualization. The package is written in a function based (would be pivoted to OPP style in future development). The analysis module features climate variable extraction and estimation of statistical long-term means and difference. Statistical tools like PCA or EOF analysis are included for specific estimates and many other classical methods like testing, OLS estiates, etc. 

## installation 
-------------
Can be installed by chećking the dependencies in pyClimat.yml (But it will be compiled afterwards for easy installatoin)



Documentation 
-------------
Would be compile with python sphinix shortly (But the codes are highy commented)
