# Initialise all packages for just importing Package 

from .plots import *
from .plot_utils import *
from .analysis import *
from .data import *

# try:
    
#     from .plots import *
#     from .plot_utils import *
#     from .analysis import *
#     from .data import *
# except:
#     from plots import *
#     from plot_utils import *
#     from analysis import *
#     from data import *
 